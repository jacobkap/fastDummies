library(testthat)
library(DMCFB)

test_check("DMCFB")
