# Version 1.3.1

## New Features

* Parallel reading of data is added to readBismark-method.

## Removed

* export.bed is removed due to warning. Will be modified and added in the next release.

# Version 0.99.1

## New Features

* None.

## CHANGES IN VERSION 0.99.1 (2019-06-02)

* None.
